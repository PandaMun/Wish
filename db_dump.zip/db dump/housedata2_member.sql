-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: housedata2
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `user_id` varchar(16) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `user_password` varchar(16) NOT NULL,
  `address` varchar(45) DEFAULT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `authority` varchar(10) DEFAULT 'user',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES ('adfasdffds','123','123','123','123',NULL),('alex','alex','alex','alex','11',NULL),('andy','andy','0000','부산 기장군 용수리 1387','010-0000-0000','user'),('billy','billy','0000','서울 강남구 역삼동 798','010-0000-0000','user'),('caley','caley','0000','서울 강남구 역삼동 797-27','010-0000-0000','user'),('eden','eden','0000','서울 강남구 역삼동 785-10','010-0000-0000','user'),('elin','elin','0000','서울 강남구 역삼동 785-2','010-0000-0000','user'),('fanny','fanny','0000','서울 광진구 화양동 4-20','010-0000-0000','user'),('ffff','123','123','123','123',NULL),('gili','gili','0000','서울 광진구 화양동 42-3','010-0000-0000','user'),('hedy','hedy','0000','서울 마포구 합정동 413-15','010-0000-0000','user'),('hope','hope','0000','서울 마포구 합정동 363-29 ','010-0000-0000','user'),('hue','hue','0000','서울 마포구 상수동 310-23','010-0000-0000','user'),('isabel','isabel','0000','서울 마포구 창전동 6-104','010-0000-0000','user'),('ivy','ivy','0000','대구 북구 금호동 199','010-0000-0000','user'),('jack','jack','0000','인천 강화군 양도면 능내리 894','010-0000-0000','user'),('jacob','jacob','0000','인천 강화군 양도면 조산리 754','010-0000-0000','user'),('jamie','jamie','0000','인천 남동구 논현동 673-1','010-0000-0000','user'),('lris','lris','0000','서울 마포구 상수동 93-6','010-0000-0000','user'),('seojeong','seojeong','0000','경기 시흥시 신천동 734-6','010-0000-0000','user'),('ssafy','ssafy','1234','ssafy','010-0000-0000','admin');
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-16 17:52:12
